package com.book.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.book.domain.Book;
import com.book.fallback.BookServiceFallBack;

@FeignClient(name="application",fallback=BookServiceFallBack.class)
public interface BookServiceProxy {

	@GetMapping(value="/shop/get", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getDetails();
	
	@GetMapping(value="/shop/getbyId/{bookId}",produces = {MediaType.APPLICATION_JSON_VALUE})
	public Book getById(@PathVariable Integer bookId);
}
