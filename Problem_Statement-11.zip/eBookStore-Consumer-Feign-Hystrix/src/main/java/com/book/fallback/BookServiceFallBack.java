package com.book.fallback;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.book.domain.Book;
import com.book.proxy.BookServiceProxy;

@Component
public class BookServiceFallBack implements BookServiceProxy{

    @Override
	public List<Book> getDetails() {
	//	 TODO Auto-generated method stub
		return Arrays.asList(new Book());
	}

	@Override
	public Book getById(Integer bookId) {

		return new Book(bookId,"french","ramesh",2021);
	}

}
